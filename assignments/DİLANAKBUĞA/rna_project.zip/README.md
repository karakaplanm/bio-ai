# RNA Sequence Classification (mRNA vs miRNA)

This project demonstrates a simple LSTM-based deep learning model using TensorFlow/Keras to classify RNA sequences as either:

- **mRNA (label = 1)**
- **miRNA (label = 0)**

The dataset used here is a small dummy set for demonstration purposes.

## 📌 How It Works
1. RNA sequences are encoded numerically:
   - A = 0  
   - C = 1  
   - G = 2  
   - U = 3  

2. Sequences are reshaped for LSTM input:  
   **(samples, sequence_length, features)**

3. A simple neural network architecture:
   - LSTM layer  
   - Dense (ReLU)  
   - Dense (sigmoid)

4. Model is trained for 25 epochs.

5. The script outputs a prediction for one example sequence:  
   `"AUGCGAUUGC"`

## 📁 Files in This ZIP
- `rna_classifier.py` → The Python model script  
- `README.md` → Project explanation and usage info  

## ▶️ How to Run
Install TensorFlow if needed:

```
pip install tensorflow
```

Then run:

```
python rna_classifier.py
```

## ✨ Notes
This example is for learning purposes and uses a very small artificial dataset.  
For real biological classification, much larger labeled RNA datasets should be used.

Enjoy exploring RNA deep learning models! 🚀
