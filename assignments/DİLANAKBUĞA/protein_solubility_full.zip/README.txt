This project trains a linear regression model to predict protein solubility.
Files:
- protein_solubility.py
- data_description.txt