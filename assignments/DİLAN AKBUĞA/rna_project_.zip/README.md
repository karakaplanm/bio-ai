# 1. RNA Sekans Sınıflandırma (mRNA vs miRNA)

Bu bölümde:

- RNA dizileri sayısal olarak encode edildi (A=0, C=1, G=2, U=3)
- Dummy bir RNA veri seti kullanıldı
- LSTM tabanlı bir derin öğrenme modeli kuruldu
- Model 25 epoch boyunca eğitildi
- Örnek bir dizinin sınıfı (mRNA mı, miRNA mı) tahmin edildi
- Çıktı doğrudan terminale yazdırılır

---

✏️ **Kullanılan Teknolojiler**

- TensorFlow / Keras
- NumPy
- LSTM (Long Short-Term Memory) sinir ağı modeli

---

🚀 **Çalıştırma**

Gerekli paketleri kur:

```
pip install tensorflow
```

Analizi çalıştır:

```
python rna_classifier.py
```

---

📁 **ZIP İçeriği**

- `rna_classifier.py` – Ana model kodu  
- `README.md` – Proje açıklaması  

---

🧬 **Notlar**

Bu proje yalnızca eğitim amaçlıdır ve çok küçük bir yapay veri seti kullanır.  
Gerçek biyoinformatik çalışmalarda çok daha büyük ve etiketli RNA veri setleri gereklidir.

