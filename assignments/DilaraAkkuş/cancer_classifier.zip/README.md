# Cancer Classifier Project

This zip contains:
- `cancer_classifier.ipynb`: Notebook for cancer classification model.

## How to Use
1. Open the notebook in Jupyter or Colab.
2. Install required libraries.
3. Run the cells sequentially.

